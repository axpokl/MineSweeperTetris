#include "disp.h"
int main(){
createwin(red);
clear(blue);
msgbox("red");
freshwin();
msgbox("blue");
return 0;}
